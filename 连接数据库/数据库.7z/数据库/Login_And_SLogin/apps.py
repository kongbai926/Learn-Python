from django.apps import AppConfig


class LoginAndSloginConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "Login_And_SLogin"
